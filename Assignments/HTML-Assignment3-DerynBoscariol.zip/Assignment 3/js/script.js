function toggleNav() {
    let menu = document.querySelector("#nav-list");
    menu.classList.toggle("show-small");
}